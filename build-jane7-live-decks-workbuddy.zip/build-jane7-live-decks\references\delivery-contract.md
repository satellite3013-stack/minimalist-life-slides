# 交付与文件契约

## 1. 默认交付物

同一份结构化内容默认生成四个文件：

1. `index.html`：直播版 HTML，只包含正式直播页面。
2. `share.html`：分享版 HTML，完整复制直播版并在末尾增加转化页。
3. `<主题>-直播版.pptx`：原生可编辑 PPTX，不包含推广页。
4. `<主题>-分享版.pptx`：原生可编辑 PPTX，在末尾增加同一转化页和可点击链接。

如果用户只需要其中一部分，可以缩减，但不要混淆版本。

## 2. 单一内容源

- 先创建 `presentation.json`，把页面顺序、类型、可见文字、视觉意图、讲者备注和来源放在同一模型中。
- HTML 和 PPTX 都从该模型生成，避免两边手工维护导致文案不一致。
- 分享配置单独放在 `share-config.json`，由构建脚本追加到末页。

## 3. HTML 要求

- 使用 `assets/html/template.html`，不要从空白重新设计。
- Logo 以内嵌 data URI 交付；除指定网络字体外，不依赖本地绝对路径。
- 同一 HTML 地址自动适配桌面与手机竖屏。
- 网页不渲染底部控制栏、页数、备注面板或编辑开关。
- 桌面保留键盘与滚轮翻页，并用 `F` 进入或退出浏览器全屏；手机使用上下滑动翻页，不能让任何导航遮挡 CTA。
- 分享页 CTA 使用原生 `<a>`，链接可复制、可搜索、可点击。
- 使用 `scripts/build-jane7-html.mjs` 构建，并使用 `scripts/qa-jane7-html.mjs` 检查。

示例：

```powershell
& $RUNTIME_NODE scripts/build-jane7-html.mjs `
  --deck D:\project\presentation.json `
  --share-config D:\project\share-config.json `
  --output-dir D:\project\dist
```

## 4. PPTX 要求

- 使用 Presentations 工作流和 `@oai/artifact-tool` 生成宽屏 PPTX。
- 以 `assets/html/template.html`、`references/brand-system.md` 和用户最终确认内容为视觉约束，不保留或复用历史 HTML 与过期截图。
- 标题、正文、数字、公式、卡片、分隔线和简单图表使用原生文本/形状；图标可用 SVG。
- 保持封面无 Logo、内容页右上 Logo、无页码、纯白背景和直播安全区。
- 分享版 CTA 写入原生超链接。
- 讲者备注保留原文线索与 `[Sources]`；外部事实和素材必须可追溯。
- 若动画能力受限，优先结构化可编辑和静态排版一致性。

## 5. GitHub Pages

- 根地址部署 `index.html`。
- 分享地址部署 `share.html`，例如 `/share.html`。
- 推送前先让用户确认分享页文案和链接。
- 推送后分别验证两个 URL 返回 200、页数正确、手机滑动可用、CTA 指向正确。
- 不把内部文稿、结构化数据、构建脚本或 QA 资料上传到公开仓库，除非用户明确要求。

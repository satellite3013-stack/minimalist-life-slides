import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const modulesPath = process.env.RUNTIME_NODE_MODULES;
if (!modulesPath) throw new Error("RUNTIME_NODE_MODULES is required");
const { chromium } = require(path.join(modulesPath, "playwright"));

function parseArgs(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (!item.startsWith("--")) continue;
    const key = item.slice(2);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for --${key}`);
    result[key] = value;
    index += 1;
  }
  return result;
}

const args = parseArgs(process.argv.slice(2));
if (!args.dir) {
  throw new Error("Usage: qa-jane7-html.mjs --dir <output-dir> [--live index.html] [--share share.html] [--preview-dir <dir>]");
}

const rootDir = path.resolve(args.dir);
const files = [args.live || "index.html"];
const shareFile = args.share || "share.html";
if (fs.existsSync(path.join(rootDir, shareFile))) files.push(shareFile);
const previewDir = path.resolve(args["preview-dir"] || path.join(rootDir, "qa-previews"));
fs.mkdirSync(previewDir, { recursive: true });

const server = http.createServer((request, response) => {
  const pathname = decodeURIComponent(new URL(request.url, "http://127.0.0.1").pathname);
  const relative = pathname.replace(/^\//, "") || files[0];
  const resolved = path.resolve(rootDir, relative);
  if (!resolved.startsWith(rootDir) || !fs.existsSync(resolved)) {
    response.writeHead(404); response.end("Not found"); return;
  }
  response.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
  fs.createReadStream(resolved).pipe(response);
});

await new Promise(resolve => server.listen(0, "127.0.0.1", resolve));
const port = server.address().port;
const browser = await chromium.launch({
  headless: true,
  executablePath: process.env.BROWSER_EXECUTABLE || "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
});
const noMotion = "*{animation:none!important}.reveal,.reveal-left,.reveal-scale{transition:none!important;opacity:1!important;transform:none!important}";

async function checkSlides(file, viewport, label) {
  const page = await browser.newPage({ viewport, deviceScaleFactor: 1 });
  await page.goto(`http://127.0.0.1:${port}/${encodeURI(file)}`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => window.__deckReady === true);
  const legacyUiCount = await page.locator(".deck-controls,.deck-status,.notes-panel,.edit-hotzone,.edit-toggle").count();
  const slideCount = await page.locator(".slide").count();
  const overflows = [];
  const titleFailures = [];
  for (let index = 0; index < slideCount; index += 1) {
    await page.goto(`http://127.0.0.1:${port}/${encodeURI(file)}?qa=${label}-${index + 1}#${index + 1}`, { waitUntil: "networkidle" });
    await page.waitForFunction(() => window.__deckReady === true);
    await page.addStyleTag({ content: noMotion });
    const overflow = await page.locator(".slide.active").evaluate(slide => {
      const slideRect = slide.getBoundingClientRect();
      const candidates = [...slide.querySelectorAll("h1,h2,[data-editable],svg,img,a,.bottleneck,.ratio-visual,.rings,.cover-shape")];
      return candidates.filter(node => {
        const rect = node.getBoundingClientRect();
        if (!rect.width || !rect.height) return false;
        return rect.left < slideRect.left - 1 || rect.top < slideRect.top - 1 || rect.right > slideRect.right + 1 || rect.bottom > slideRect.bottom + 1;
      }).map(node => node.className?.baseVal || node.className || node.tagName);
    });
    if (overflow.length) overflows.push({ slide: index + 1, elements: overflow });
    const titleState = await page.locator(".slide.active").evaluate(slide => {
      const heading = slide.querySelector(".cover-title,.slide-title,.closing-title,.share-title,h1,h2");
      if (!heading) return { passed: false, reason: "missing heading node" };
      const style = getComputedStyle(heading);
      const rect = heading.getBoundingClientRect();
      const text = heading.innerText.trim();
      const passed = style.display !== "none"
        && style.visibility !== "hidden"
        && Number(style.opacity) > 0
        && rect.width > 1
        && rect.height > 1
        && text.length > 0;
      return { passed, text, display: style.display, visibility: style.visibility, opacity: style.opacity, width: rect.width, height: rect.height };
    });
    if (!titleState.passed) titleFailures.push({ slide: index + 1, ...titleState });
  }
  await page.goto(`http://127.0.0.1:${port}/${encodeURI(file)}?qa=${label}-last#${slideCount}`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => window.__deckReady === true);
  await page.addStyleTag({ content: noMotion });
  await page.screenshot({ path: path.join(previewDir, `${path.parse(file).name}-${label}-last.png`) });
  const pageTitle = await page.title();
  const lastSlide = await page.locator(".slide.active").getAttribute("data-id");
  const ctaLocator = page.locator(".slide.active .share-button");
  const ctaCount = await ctaLocator.count();
  const cta = ctaCount > 0
    ? await ctaLocator.evaluate(link => ({ text: link.textContent.trim(), href: link.href }))
    : null;
  await page.close();
  return { slideCount, overflows, titleFailures, pageTitle, lastSlide, cta, legacyUiCount };
}

async function checkVerticalSwipe(file) {
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  const page = await context.newPage();
  await page.goto(`http://127.0.0.1:${port}/${encodeURI(file)}#1`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => window.__deckReady === true);
  const client = await context.newCDPSession(page);
  const swipe = async (startY, endY) => {
    await client.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ x: 195, y: startY }] });
    await client.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ x: 195, y: endY }] });
    await client.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
    await page.waitForTimeout(120);
    return page.evaluate(() => location.hash);
  };
  const upward = await swipe(650, 250);
  const downward = await swipe(250, 650);
  await context.close();
  return { upward, downward, passed: upward === "#2" && downward === "#1" };
}

async function checkReplayFab(file, isShare) {
  const widths = isShare ? [375, 390, 430] : [390];
  const checks = [];
  for (const width of widths) {
    const context = await browser.newContext({ viewport: { width, height: 844 }, hasTouch: true, isMobile: true });
    const page = await context.newPage();
    await page.goto(`http://127.0.0.1:${port}/${encodeURI(file)}#2`, { waitUntil: "networkidle" });
    await page.waitForFunction(() => window.__deckReady === true);
    const count = await page.locator("#replayFab").count();
    if (!isShare) {
      checks.push({ width, count, passed: count === 0 });
      await context.close();
      continue;
    }
    if (count !== 1) {
      checks.push({ width, count, passed: false, reason: "missing or duplicate replay FAB" });
      await context.close();
      continue;
    }
    await page.locator("#replayFab").evaluate(fab => fab.classList.add("visible", "intro"));
    const metrics = await page.locator("#replayFab").evaluate(fab => {
      const label = fab.querySelector(".replay-fab-expanded");
      const brand = document.getElementById("globalBrand");
      const fabRect = fab.getBoundingClientRect();
      const labelRect = label.getBoundingClientRect();
      const brandRect = brand.getBoundingClientRect();
      return {
        text: label.textContent.trim(),
        whiteSpace: getComputedStyle(label).whiteSpace,
        labelHeight: labelRect.height,
        fabLeft: fabRect.left,
        fabRight: fabRect.right,
        viewportWidth: innerWidth,
        centerDelta: Math.abs((fabRect.left + fabRect.width / 2) - (brandRect.left + brandRect.width / 2))
      };
    });
    const passed = metrics.text.length > 0
      && metrics.whiteSpace === "nowrap"
      && metrics.labelHeight < 24
      && metrics.fabLeft >= 0
      && metrics.fabRight <= metrics.viewportWidth
      && metrics.centerDelta <= 1;
    checks.push({ width, ...metrics, passed });
    await context.close();
  }
  return { checks, passed: checks.every(check => check.passed) };
}

const results = {};
let passed = true;
for (const file of files) {
  const desktop = await checkSlides(file, { width: 1920, height: 1080 }, "desktop");
  const mobile = await checkSlides(file, { width: 390, height: 844 }, "mobile");
  const swipe = await checkVerticalSwipe(file);
  const replayFab = await checkReplayFab(file, file === shareFile);
  const ctaPassed = file === shareFile ? Boolean(desktop.cta?.href && mobile.cta?.href) : desktop.cta === null && mobile.cta === null;
  const legacyUiPassed = desktop.legacyUiCount === 0 && mobile.legacyUiCount === 0;
  const titlesPassed = desktop.titleFailures.length === 0 && mobile.titleFailures.length === 0;
  const filePassed = desktop.overflows.length === 0 && mobile.overflows.length === 0 && titlesPassed && swipe.passed && ctaPassed && legacyUiPassed && replayFab.passed;
  if (!filePassed) passed = false;
  results[file] = { desktop, mobile, swipe, replayFab, passed: filePassed };
}

await browser.close();
await new Promise(resolve => server.close(resolve));
const report = { passed, files: results };
fs.writeFileSync(path.join(rootDir, "jane7-html-qa.json"), `${JSON.stringify(report, null, 2)}\n`, "utf8");
console.log(JSON.stringify(report, null, 2));
if (!passed) process.exitCode = 1;

# Jane7 mobile layout standard

Apply this standard to every portrait HTML version and read it before mobile QA.

## Titles

- Do not rely only on browser auto-wrapping for Chinese headings.
- For every heading that needs more than one mobile line, add `visible.mobileTitleLines` as an array of semantic lines.
- The renderer must always create a visible `.mobile-title` node. When `mobileTitleLines` is absent, render `visible.title` as the mobile fallback; never return only the desktop title because mobile CSS hides `.desktop-title`.
- Concatenating `mobileTitleLines` must reproduce `visible.title` exactly; the field controls layout only and must not rewrite copy.
- Never leave one Chinese character, one number, or punctuation alone on the last line.
- Use about 68px, 64px, or 60px for short, medium, or long mobile headings. Keep every line of a heading at the same size.
- Test with the system fallback font as well as the preferred web font because WeChat may use different glyph metrics.

## Numbers and geometry

- Keep numbers with units, ratios, and formulas in one non-wrapping node, such as `20 / 80`, `80–90小时`, and `4小时`.
- Apply `white-space: nowrap` to these nodes.
- Give circles, rings, and square charts equal width and height, `aspect-ratio: 1 / 1`, and `flex-shrink: 0` or equivalent grid protection.
- Do not permit a narrow container to turn a circle into an ellipse.

## Share replay entry

- Render the floating replay entry only in `share.html`, never in `index.html`.
- On its first eligible content page, expand it once as `▶ 看回放 →` for about 4.5 seconds, then collapse it to the compact `▶` entry.
- Keep the expanded label on one line with `white-space: nowrap`, `flex-wrap: nowrap`, and non-shrinking icon/text spans. Apply `-webkit-text-size-adjust: 100%` to prevent iOS text inflation from forcing a wrap.
- At 375px, 390px, and 430px viewport widths, keep the full expanded pill inside the viewport. Align its horizontal center to the Logo center and keep it above the browser safe area.

## QA

- Render every page at 390×844 and spot-check 375px and 430px widths.
- Record actual title line counts and visually inspect the last line of every title.
- Assert on every page that the active heading has non-empty `innerText`, non-zero geometry, and visible computed styles.
- Reject any title with an orphan character, split number/unit, accidental third line, or punctuation-only line.
- Reject any circle whose rendered width and height differ by more than one pixel before stage scaling.
- Reject a floating replay CTA whose label wraps, whose bounding box leaves the viewport, or whose center differs from the Logo center by more than one pixel.
- Run mobile QA with the preferred font unavailable once to exercise the fallback font path.

---
name: build-jane7-live-decks
description: Build Jane7/简七 livestream presentation packages from scripts or structured content, including editable live/share HTML and native PPTX versions. Use when Codex needs to turn a new 简七直播稿 into branded slides, reproduce the established 简七 template, update an existing Jane7 live deck, create separate 直播版/分享版 outputs, add mobile portrait behavior, or publish the final HTML to GitHub Pages.
---

# Build Jane7 Live Decks

Use one structured content model to produce consistent Jane7 livestream HTML and PPTX deliverables. Preserve source fidelity, brand geometry, editability, mobile behavior, and the separation between the live and share versions.

## Load the standards

1. Read `references/input-contract.md` and `references/content-architecture.md` before structuring a new script.
2. Read `references/brand-system.md` before designing or editing layouts.
3. Read `references/delivery-contract.md` before building files.
4. Read `references/qa-checklist.md` before declaring completion or publishing.
5. Read `references/mobile-layout.md` before building or validating portrait HTML.
6. In Tencent WorkBuddy, also read `references/workbuddy-runtime.md` before running scripts or building PPTX.

Do not rely on conversation memory for brand rules when these references are available.

## Workflow

### 1. Audit the inputs

- Read the entire livestream script and every supplied source before writing slide titles.
- Identify missing items from `references/input-contract.md`.
- Continue with documented defaults when missing details do not materially change the result; ask only for decisions that would change claims, promotion content, or publication scope.
- Treat user-confirmed wording, formulas, names, data, and hierarchy as authoritative.

### 2. Build the content map

- Map each source section to one slide narrative job.
- Create `presentation.json` using `assets/reference/presentation.example.json` as a structural reference only.
- Use only the supported slide types documented in `references/content-architecture.md`.
- Run:

```powershell
& $RUNTIME_NODE scripts/validate-jane7-deck.mjs D:\project\presentation.json
```

- Resolve all errors. Review every warning against the user's source instead of automatically rewriting it.

### 3. Confirm the direction efficiently

- For a new program or materially different content family, render three representative pages first: cover, one dense content/diagram page, and one interaction or share page.
- Use the final template and the numeric rules in `references/brand-system.md` to compare margins, title hierarchy, Logo position, type scale, and density.
- Skip a separate prototype round when the user explicitly asks to proceed directly with the established Jane7 standard.

### 4. Build the HTML versions

- Use `assets/html/template.html`; do not recreate the shell from scratch.
- Use the bundled `assets/logo.png` unless the user provides a newer approved Logo.
- Create a user-confirmed `share-config.json` from `assets/reference/share-config.example.json`.
- Run `scripts/build-jane7-html.mjs` to create `index.html` and `share.html`.
- Keep all essential text in the DOM. Embed the Logo in the file. Keep the live version free of promotion.
- Do not render a bottom control bar, page counter, notes panel, or edit toggle on desktop or mobile.
- Preserve desktop keyboard and wheel navigation, mobile vertical swipe navigation, and the `F` keyboard shortcut for browser fullscreen.

### 5. Build the PPTX versions

- Invoke the Presentations skill and follow its complete local PPTX workflow.
- Use `presentation.json` as the content source and the bundled HTML/PNG references as the explicit visual direction.
- Generate native 16:9 slides with `@oai/artifact-tool`; keep titles, body text, numbers, formulas, dividers, cards, and simple diagrams editable.
- Use SVG or native shapes for icons. Never use full-slide screenshots as slide backgrounds.
- Produce a live PPTX without promotion and a share PPTX with the same final CTA page and hyperlink as `share.html`.
- Match visible wording across HTML and PPTX exactly.

### 6. Validate

- Load workspace dependencies and use only the returned runtime paths.
- Run `scripts/qa-jane7-html.mjs` for desktop/mobile overflow and touch navigation.
- Render every PPTX page and inspect it at full size. Run the Presentations overflow test.
- Apply every item in `references/qa-checklist.md`.
- Do not hand off with unresolved clipping, accidental wrapping, mismatched copy, broken links, missing Logo, or content hidden inside images.

### 7. Publish only when authorized

- Keep `index.html` at the root URL and `share.html` at the distinct `/share.html` URL.
- Push only after the user approves final visible copy and explicitly asks to publish.
- Rebuild `build-jane7-live-decks-workbuddy.zip` from the current cleaned Skill whenever the final template, rules, scripts, or assets change.
- Publish `index.html`, `share.html`, and `build-jane7-live-decks-workbuddy.zip` together in the GitHub Pages repository so the downloadable WorkBuddy Skill never lags behind the latest webpages.
- Verify both deployed URLs, page counts, mobile swipe behavior, and CTA destination after GitHub Pages refreshes.
- Verify the deployed ZIP returns HTTP 200 and matches the local ZIP byte size.

## Non-negotiable rules

- Preserve the user's content terminology and logical relationships.
- Use a pure white background, Jane7 orange, the approved Logo, no Logo on the cover, and no page numbers.
- Keep meaningful content inside the live-safe center area.
- Limit body typography to two sizes.
- Use consistent orange line icons and small solid arrows.
- Use 1.5-second unified HTML entrance motion.
- Never add a visible bottom navigation control bar, page counter, notes panel, or edit toggle.
- Keep up/down swipe navigation on mobile portrait and `F` fullscreen on desktop.
- Keep the live and share versions separate.
- Keep important content searchable, editable, and structurally represented.

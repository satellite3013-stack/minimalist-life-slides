import fs from "node:fs";
import path from "node:path";

const file = process.argv[2];
if (!file) throw new Error("Usage: validate-jane7-deck.mjs <presentation.json>");
const deck = JSON.parse(fs.readFileSync(path.resolve(file), "utf8"));
const allowedTypes = new Set([
  "cover", "interaction", "story", "definition", "contrast", "comparison",
  "case-problem", "case-action", "case-result", "framework", "principle",
  "scene-core", "scene-boundary", "diagram", "synthesis", "closing", "share-cta"
]);
const errors = [];
const warnings = [];

if (!Array.isArray(deck.slides) || deck.slides.length === 0) errors.push("slides must be a non-empty array");
const ids = new Set();

function walkStrings(value, visit, trail = "") {
  if (typeof value === "string") visit(value, trail);
  else if (Array.isArray(value)) value.forEach((item, index) => walkStrings(item, visit, `${trail}[${index}]`));
  else if (value && typeof value === "object") Object.entries(value).forEach(([key, item]) => walkStrings(item, visit, trail ? `${trail}.${key}` : key));
}

for (const [index, slide] of (deck.slides || []).entries()) {
  const label = slide.id || `slide-${index + 1}`;
  if (!slide.id) errors.push(`slide ${index + 1}: missing id`);
  else if (ids.has(slide.id)) errors.push(`${label}: duplicate id`);
  else ids.add(slide.id);
  if (!allowedTypes.has(slide.type)) errors.push(`${label}: unsupported type ${slide.type}`);
  if (!slide.visible?.title) errors.push(`${label}: missing visible.title`);
  if (slide.number != null && slide.number !== index + 1) warnings.push(`${label}: number does not match slide order`);
  const title = slide.visible?.title || "";
  const mobileTitleLines = slide.visible?.mobileTitleLines;
  if (mobileTitleLines != null) {
    if (!Array.isArray(mobileTitleLines) || mobileTitleLines.length < 1 || mobileTitleLines.length > 3 || mobileTitleLines.some(line => typeof line !== "string" || !line.trim())) {
      errors.push(`${label}: visible.mobileTitleLines must contain one to three non-empty strings`);
    } else {
      if (mobileTitleLines.join("") !== title) errors.push(`${label}: mobileTitleLines must reproduce visible.title exactly`);
      const finalLine = mobileTitleLines.at(-1).replace(/[，。！？；：、,.!?;:\s]/g, "");
      if (mobileTitleLines.length > 1 && finalLine.length <= 1) errors.push(`${label}: mobile title has an orphan final line`);
    }
  } else if (title.length > 10) {
    warnings.push(`${label}: review mobile wrapping and add visible.mobileTitleLines when the title needs semantic line breaks`);
  }
  if (/只有|都是/.test(title)) warnings.push(`${label}: title may sound too absolute: ${title}`);
  if (title.length > 18 && !/[，：；、？！]/.test(title)) warnings.push(`${label}: long title has no natural line-break punctuation`);
  walkStrings(slide.visible, (text, trail) => {
    if (/["][^\n"]+["]/.test(text)) warnings.push(`${label}.${trail}: use Chinese corner quotes 「」 instead of straight quotes`);
  });
  if (slide.type === "interaction" && slide.visible?.choices?.length) {
    warnings.push(`${label}: open interaction pages should contain only the question and danmaku prompt unless options are explicitly requested`);
  }
  if (slide.type === "framework" && slide.visible?.steps?.length !== 2) {
    errors.push(`${label}: framework requires exactly two structured steps; use case-action for three parallel actions`);
  }
  if (slide.type === "case-action" && (slide.visible?.steps?.length < 1 || slide.visible?.steps?.length > 3)) {
    errors.push(`${label}: case-action requires one to three steps`);
  }
}

const report = { passed: errors.length === 0, slides: deck.slides?.length || 0, errors, warnings };
console.log(JSON.stringify(report, null, 2));
if (errors.length) process.exitCode = 1;

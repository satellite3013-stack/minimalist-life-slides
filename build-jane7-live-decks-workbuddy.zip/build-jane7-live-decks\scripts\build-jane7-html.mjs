import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const skillDir = path.resolve(scriptDir, "..");

function parseArgs(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (!item.startsWith("--")) continue;
    const key = item.slice(2);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for --${key}`);
    result[key] = value;
    index += 1;
  }
  return result;
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(path.resolve(filePath), "utf8"));
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function escapeAttribute(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll('"', "&quot;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function assertDeck(deck) {
  if (!deck || !Array.isArray(deck.slides) || deck.slides.length === 0) {
    throw new Error("Deck JSON must contain a non-empty slides array");
  }
  const ids = new Set();
  for (const [index, slide] of deck.slides.entries()) {
    if (!slide.id) throw new Error(`Slide ${index + 1} is missing id`);
    if (ids.has(slide.id)) throw new Error(`Duplicate slide id: ${slide.id}`);
    ids.add(slide.id);
    if (!slide.type) throw new Error(`Slide ${slide.id} is missing type`);
    if (!slide.visible?.title) throw new Error(`Slide ${slide.id} is missing visible.title`);
  }
}

function renderHtml(template, deck, logoDataUri, pageMeta, replayFab = null) {
  const title = pageMeta.title || deck.project?.title || deck.slides[0].visible.title || "简七直播";
  const description = pageMeta.description || deck.project?.description || deck.slides[0].visible.subtitle || title;
  const socialMeta = [
    `<meta name="description" content="${escapeAttribute(description)}" />`,
    `<meta property="og:title" content="${escapeAttribute(title)}" />`,
    `<meta property="og:description" content="${escapeAttribute(description)}" />`,
    `<meta property="og:type" content="website" />`,
    pageMeta.url ? `<meta property="og:url" content="${escapeAttribute(pageMeta.url)}" />` : ""
  ].filter(Boolean).join("\n  ");

  return template
    .replace(/<title>.*?<\/title>/s, `<title>${escapeAttribute(title)}</title>\n  ${socialMeta}`)
    .replace("__DECK_JSON__", JSON.stringify(deck).replace(/<\//g, "<\\/"))
    .replace("__LOGO_DATA_URI__", logoDataUri)
    .replace("__SHARE_REPLAY_FAB_CSS__", replayFab?.css || "")
    .replace("__SHARE_REPLAY_FAB_HTML__", replayFab?.html || "")
    .replace("__SHARE_REPLAY_FAB_SCRIPT__", replayFab?.script || "");
}

function makeReplayFab({ url, label = "看回放", durationMs = 4500 }) {
  const safeUrl = escapeAttribute(url);
  const safeLabel = escapeAttribute(label);
  const safeDuration = Number.isFinite(Number(durationMs)) ? Math.max(1000, Number(durationMs)) : 4500;
  return {
    css: `
    /* === SHARE-ONLY FLOATING REPLAY CTA === */
    .replay-fab {
      position: fixed;
      left: var(--replay-fab-center-x, calc(100vw - clamp(180px, 14vw, 280px)));
      bottom: calc(28px + env(safe-area-inset-bottom, 0px));
      z-index: 1050;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      flex-wrap: nowrap;
      white-space: nowrap;
      -webkit-text-size-adjust: 100%;
      gap: 0;
      min-width: 44px;
      height: 44px;
      padding: 0;
      border: 1.5px solid rgba(243,108,33,.48);
      border-radius: 999px;
      background: rgba(255,250,246,.94);
      color: var(--orange);
      box-shadow: 0 7px 20px rgba(243,108,33,.12);
      font: 800 15px/1 var(--font-body);
      text-decoration: none;
      opacity: 0;
      transform: translate(-50%, 14px);
      pointer-events: none;
      transition: opacity 1.5s ease, transform 1.5s var(--ease-out-expo), min-width .32s ease, height .32s ease, padding .32s ease, box-shadow .2s ease, background .2s ease;
    }
    .replay-fab.visible { opacity: .82; transform: translate(-50%, 0); pointer-events: auto; }
    .replay-fab.intro { min-width: 136px; height: 48px; padding: 0 19px; gap: 7px; background: rgba(255,250,246,.99); box-shadow: 0 9px 24px rgba(243,108,33,.17); opacity: 1; }
    .replay-fab-play, .replay-fab-expanded, .replay-fab-arrow { flex: 0 0 auto; white-space: nowrap; }
    .replay-fab-play { font-size: 11px; line-height: 1; }
    .replay-fab-expanded, .replay-fab-arrow { display: none; }
    .replay-fab.intro .replay-fab-expanded, .replay-fab.intro .replay-fab-arrow { display: inline; }
    .replay-fab:focus-visible { outline: 4px solid rgba(243,108,33,.25); outline-offset: 5px; }
    .replay-fab-arrow { font-size: 16px; line-height: 1; }
    @media (hover: hover) and (pointer: fine) {
      .replay-fab.visible:hover { min-width: 136px; height: 48px; padding: 0 19px; gap: 7px; background: rgba(255,250,246,.99); box-shadow: 0 9px 24px rgba(243,108,33,.17); opacity: 1; }
      .replay-fab:hover .replay-fab-expanded, .replay-fab:hover .replay-fab-arrow { display: inline; }
    }
    @media screen and (max-width: 700px) and (orientation: portrait) {
      .replay-fab { bottom: calc(76px + env(safe-area-inset-bottom, 0px)); min-width: 38px; height: 38px; padding: 0; gap: 0; font-size: 13px; box-shadow: 0 6px 16px rgba(243,108,33,.11); }
      .replay-fab.intro { min-width: 110px; height: 40px; padding: 0 10px; gap: 5px; font-size: 14px; }
      .replay-fab-play { font-size: 9px; }
      .replay-fab-arrow { font-size: 14px; }
    }`,
    html: `<a class="replay-fab" id="replayFab" href="${safeUrl}" aria-label="查看往期直播回放"><span class="replay-fab-play" aria-hidden="true">▶</span><span class="replay-fab-expanded">${safeLabel}</span><span class="replay-fab-arrow" aria-hidden="true">→</span></a>`,
    script: `<script>
    (() => {
      const fab = document.getElementById('replayFab');
      const brand = document.getElementById('globalBrand');
      if (!fab || !brand || typeof presentation === 'undefined') return;
      let hintShown = false;
      let hintTimer = 0;
      const align = () => {
        const rect = brand.getBoundingClientRect();
        fab.style.setProperty('--replay-fab-center-x', \`${'${rect.left + rect.width / 2}'}px\`);
      };
      const update = index => {
        const shouldShow = index > 0 && index < presentation.slides.length - 1;
        fab.classList.toggle('visible', shouldShow);
        if (!shouldShow) {
          clearTimeout(hintTimer);
          fab.classList.remove('intro');
          return;
        }
        if (!hintShown) {
          hintShown = true;
          fab.classList.add('intro');
          hintTimer = setTimeout(() => fab.classList.remove('intro'), ${safeDuration});
        }
      };
      const originalShowSlide = presentation.showSlide.bind(presentation);
      presentation.showSlide = index => {
        originalShowSlide(index);
        requestAnimationFrame(() => { align(); update(index); });
      };
      window.addEventListener('resize', () => requestAnimationFrame(align));
      requestAnimationFrame(() => { align(); update(presentation.currentSlide); });
    })();
  </script>`
  };
}

function makeShareSlide(config, number) {
  if (config.slide) return { ...clone(config.slide), number };
  const visible = config.visible || config;
  const required = ["title", "intro", "cards", "button", "url"];
  for (const key of required) {
    if (!visible[key]) throw new Error(`Share config is missing ${key}`);
  }
  if (!Array.isArray(visible.cards) || visible.cards.length !== 3) {
    throw new Error("Share config must contain exactly three cards");
  }
  return {
    id: config.id || `s${String(number).padStart(2, "0")}`,
    section: config.section || "继续探索",
    type: "share-cta",
    number,
    narrativeJob: "承接本期内容，引导用户进入后续内容或回放列表。",
    visible: {
      eyebrow: visible.eyebrow || config.section || "继续探索",
      title: visible.title,
      intro: visible.intro,
      cards: visible.cards,
      microcopy: visible.microcopy || "更多内容持续更新",
      button: visible.button,
      url: visible.url
    },
    visual: {
      layout: "三主题推荐卡＋主行动按钮",
      icons: visible.cards.map(card => card.icon || "sparkles"),
      nativeShapes: ["主题卡片", "橙色行动按钮"],
      images: []
    },
    speakerNotes: config.speakerNotes || "分享版转化入口。仅在用户主动点击后跳转。"
  };
}

const args = parseArgs(process.argv.slice(2));
if (!args.deck || !args["output-dir"]) {
  throw new Error("Usage: build-jane7-html.mjs --deck <deck.json> --output-dir <dir> [--share-config <share.json>] [--logo <logo.png>] [--live-name index.html] [--share-name share.html]");
}

const template = fs.readFileSync(path.join(skillDir, "assets", "html", "template.html"), "utf8");
const deck = readJson(args.deck);
assertDeck(deck);

const logoPath = path.resolve(args.logo || path.join(skillDir, "assets", "logo.png"));
const logoDataUri = `data:image/png;base64,${fs.readFileSync(logoPath).toString("base64")}`;
const outputDir = path.resolve(args["output-dir"]);
fs.mkdirSync(outputDir, { recursive: true });

const liveName = args["live-name"] || "index.html";
const livePath = path.join(outputDir, liveName);
const liveMeta = {
  title: deck.project?.pageTitle || deck.project?.title,
  description: deck.project?.description,
  url: deck.project?.url
};
fs.writeFileSync(livePath, renderHtml(template, deck, logoDataUri, liveMeta), "utf8");

const result = { live: livePath, liveSlides: deck.slides.length };

if (args["share-config"]) {
  const shareConfig = readJson(args["share-config"]);
  const shareDeck = clone(deck);
  const shareSlide = makeShareSlide(shareConfig, shareDeck.slides.length + 1);
  shareDeck.slides.push(shareSlide);
  shareDeck.project = {
    ...shareDeck.project,
    slideCount: shareDeck.slides.length,
    purpose: "用户分享与转化"
  };
  const shareName = args["share-name"] || "share.html";
  const sharePath = path.join(outputDir, shareName);
  const shareMeta = {
    title: shareConfig.pageTitle || `${deck.project?.title || deck.slides[0].visible.title}｜用户分享版｜简七`,
    description: shareConfig.description || shareSlide.visible.intro,
    url: shareConfig.pageUrl
  };
  const floatingReplay = shareConfig.floatingReplay === false ? null : makeReplayFab({
    url: shareSlide.visible.url,
    label: shareConfig.floatingReplay?.label || "看回放",
    durationMs: shareConfig.floatingReplay?.durationMs || 4500
  });
  fs.writeFileSync(sharePath, renderHtml(template, shareDeck, logoDataUri, shareMeta, floatingReplay), "utf8");
  result.share = sharePath;
  result.shareSlides = shareDeck.slides.length;
}

console.log(JSON.stringify(result, null, 2));

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const skillDir = path.resolve(scriptDir, "..");

function parseArgs(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 1) {
    const item = argv[index];
    if (!item.startsWith("--")) continue;
    const key = item.slice(2);
    const value = argv[index + 1];
    if (!value || value.startsWith("--")) throw new Error(`Missing value for --${key}`);
    result[key] = value;
    index += 1;
  }
  return result;
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(path.resolve(filePath), "utf8"));
}

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function escapeAttribute(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll('"', "&quot;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

function assertDeck(deck) {
  if (!deck || !Array.isArray(deck.slides) || deck.slides.length === 0) {
    throw new Error("Deck JSON must contain a non-empty slides array");
  }
  const ids = new Set();
  for (const [index, slide] of deck.slides.entries()) {
    if (!slide.id) throw new Error(`Slide ${index + 1} is missing id`);
    if (ids.has(slide.id)) throw new Error(`Duplicate slide id: ${slide.id}`);
    ids.add(slide.id);
    if (!slide.type) throw new Error(`Slide ${slide.id} is missing type`);
    if (!slide.visible?.title) throw new Error(`Slide ${slide.id} is missing visible.title`);
  }
}

function renderHtml(template, deck, logoDataUri, pageMeta) {
  const title = pageMeta.title || deck.project?.title || deck.slides[0].visible.title || "简七直播";
  const description = pageMeta.description || deck.project?.description || deck.slides[0].visible.subtitle || title;
  const socialMeta = [
    `<meta name="description" content="${escapeAttribute(description)}" />`,
    `<meta property="og:title" content="${escapeAttribute(title)}" />`,
    `<meta property="og:description" content="${escapeAttribute(description)}" />`,
    `<meta property="og:type" content="website" />`,
    pageMeta.url ? `<meta property="og:url" content="${escapeAttribute(pageMeta.url)}" />` : ""
  ].filter(Boolean).join("\n  ");

  return template
    .replace(/<title>.*?<\/title>/s, `<title>${escapeAttribute(title)}</title>\n  ${socialMeta}`)
    .replace("__DECK_JSON__", JSON.stringify(deck).replace(/<\//g, "<\\/"))
    .replace("__LOGO_DATA_URI__", logoDataUri);
}

function makeShareSlide(config, number) {
  if (config.slide) return { ...clone(config.slide), number };
  const visible = config.visible || config;
  const required = ["title", "intro", "cards", "button", "url"];
  for (const key of required) {
    if (!visible[key]) throw new Error(`Share config is missing ${key}`);
  }
  if (!Array.isArray(visible.cards) || visible.cards.length !== 3) {
    throw new Error("Share config must contain exactly three cards");
  }
  return {
    id: config.id || `s${String(number).padStart(2, "0")}`,
    section: config.section || "继续探索",
    type: "share-cta",
    number,
    narrativeJob: "承接本期内容，引导用户进入后续内容或回放列表。",
    visible: {
      eyebrow: visible.eyebrow || config.section || "继续探索",
      title: visible.title,
      intro: visible.intro,
      cards: visible.cards,
      microcopy: visible.microcopy || "更多内容持续更新",
      button: visible.button,
      url: visible.url
    },
    visual: {
      layout: "三主题推荐卡＋主行动按钮",
      icons: visible.cards.map(card => card.icon || "sparkles"),
      nativeShapes: ["主题卡片", "橙色行动按钮"],
      images: []
    },
    speakerNotes: config.speakerNotes || "分享版转化入口。仅在用户主动点击后跳转。"
  };
}

const args = parseArgs(process.argv.slice(2));
if (!args.deck || !args["output-dir"]) {
  throw new Error("Usage: build-jane7-html.mjs --deck <deck.json> --output-dir <dir> [--share-config <share.json>] [--logo <logo.png>] [--live-name index.html] [--share-name share.html]");
}

const template = fs.readFileSync(path.join(skillDir, "assets", "html", "template.html"), "utf8");
const deck = readJson(args.deck);
assertDeck(deck);

const logoPath = path.resolve(args.logo || path.join(skillDir, "assets", "logo.png"));
const logoDataUri = `data:image/png;base64,${fs.readFileSync(logoPath).toString("base64")}`;
const outputDir = path.resolve(args["output-dir"]);
fs.mkdirSync(outputDir, { recursive: true });

const liveName = args["live-name"] || "index.html";
const livePath = path.join(outputDir, liveName);
const liveMeta = {
  title: deck.project?.pageTitle || deck.project?.title,
  description: deck.project?.description,
  url: deck.project?.url
};
fs.writeFileSync(livePath, renderHtml(template, deck, logoDataUri, liveMeta), "utf8");

const result = { live: livePath, liveSlides: deck.slides.length };

if (args["share-config"]) {
  const shareConfig = readJson(args["share-config"]);
  const shareDeck = clone(deck);
  const shareSlide = makeShareSlide(shareConfig, shareDeck.slides.length + 1);
  shareDeck.slides.push(shareSlide);
  shareDeck.project = {
    ...shareDeck.project,
    slideCount: shareDeck.slides.length,
    purpose: "用户分享与转化"
  };
  const shareName = args["share-name"] || "share.html";
  const sharePath = path.join(outputDir, shareName);
  const shareMeta = {
    title: shareConfig.pageTitle || `${deck.project?.title || deck.slides[0].visible.title}｜用户分享版｜简七`,
    description: shareConfig.description || shareSlide.visible.intro,
    url: shareConfig.pageUrl
  };
  fs.writeFileSync(sharePath, renderHtml(template, shareDeck, logoDataUri, shareMeta), "utf8");
  result.share = sharePath;
  result.shareSlides = shareDeck.slides.length;
}

console.log(JSON.stringify(result, null, 2));

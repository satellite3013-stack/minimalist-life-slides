# Tencent WorkBuddy 运行约定

## 必要能力

- 使用 Tencent WorkBuddy 的 Skill 导入功能加载本 Skill。
- HTML 构建脚本需要 Node.js 20 或更高版本。
- PPTX 需要启用 WorkBuddy Skill Marketplace 中的“Office Document Suite”“PPT 制作”或当前版本提供的等效演示文稿能力。
- 自动化网页截图和触摸测试优先使用 WorkBuddy 的 Agent Browser；也可以使用本机 Playwright。

## 启动检查

1. 确认 Skill 根目录存在 `SKILL.md`、`scripts/`、`references/` 和 `assets/`。
2. 运行 `node --version` 并确认版本不低于 20。
3. 检查是否已启用 Office/PPT 能力。未启用时，可以先完成内容结构和 HTML，但必须明确说明 PPTX 尚未生成。
4. 检查是否有 Agent Browser 或 Playwright。两者都没有时，执行静态验证并明确标记视觉 QA 未完成。

## 终版交互约束

- 网页不渲染底部控制栏、左右按钮、页数、备注面板或编辑开关。
- 桌面使用键盘与滚轮翻页；按 `F` 进入或退出浏览器全屏。
- 手机竖屏使用上下滑动翻页；同一网址自动切换 1080×1920 原生布局。
- 直播版与分享版必须是两个独立 HTML；分享版只在末页增加用户确认的转化内容与链接。

## 路径与降级

- 从 WorkBuddy 实际加载的 `SKILL.md` 路径解析 Skill 根目录，不写死其他产品的安装路径。
- 输出文件写入用户选择的工作目录，不写回 Skill 安装目录。
- Office/PPT 能力缺失：完成 `presentation.json` 和 HTML，报告 PPTX 阻塞，不输出截图伪装的 PPTX。
- Agent Browser/Playwright 缺失：执行静态内容验证并报告未完成视觉回归。
- GitHub 凭据缺失：保留本地最终文件并提供发布步骤，不尝试绕过认证。
